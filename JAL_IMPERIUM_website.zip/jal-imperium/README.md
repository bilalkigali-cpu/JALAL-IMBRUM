# JAL IMPERIUM — FC Mobile Community Website

A responsive, bilingual (English/Arabic) static website for the JAL IMPERIUM FC Mobile community.

## Included
- Tournament overview and rules
- Sample player rankings
- Editable community news section
- Squad builder with local-device save
- Join form that prepares an email
- Player market watchlist saved in the visitor's browser
- Mobile responsive layout and English/Arabic toggle

## Before publishing
1. Open `index.html` in a text editor.
2. Search for `ADMIN_EMAIL_HERE` and replace it with the league admin's email address. If you don't want email applications to open, connect the join form to a form backend instead.
3. Replace sample rankings and OVR values with current confirmed information.
4. Update community stats and announcements. The page clearly labels sample/placeholder information.
5. Do not add passwords or sensitive player account details.

## Publish for free with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `jal-imperium`.
3. Upload `index.html` and `README.md` to the repository's root (the top level).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then press **Save**.
7. Wait for the deployment to finish. GitHub will show the published website URL in the Pages section, usually `https://YOUR-USERNAME.github.io/jal-imperium/`.

This package does not publish the website automatically; publishing requires signing in to your own hosting account and confirming repository settings. GitHub Pages hosting and URLs can change; follow the current Pages UI if it differs.
